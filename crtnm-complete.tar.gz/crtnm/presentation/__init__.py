"""HTTP delivery layer."""

