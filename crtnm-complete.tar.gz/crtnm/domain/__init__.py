"""Business entities and enumerations."""

